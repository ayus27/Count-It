INSTALL (Chrome / Edge)
1. Unzip this folder.
2. Open chrome://extensions  ->  turn on Developer mode (top right).
3. Click "Load unpacked" and choose the unzipped folder.
4. Keep one Count It tab open (count-it-pi.vercel.app, signed in). Use CLMS in another tab.

HOW IT WORKS
- CLMS shows a small pill (bottom-right). Click it for the full tally panel with + / - for every category.
- When you click Save/Submit on a comment in CLMS, the comment is read, classified, counted, and a toast with Undo appears.
- Every change is mirrored to your real Count It page automatically (the extension clicks its + / - buttons),
  so your team goal, saved reports and Google Form report keep working as before.
- Don't also tap + in Count It for the same call, or it counts twice.

TUNING
Edit the keyword rules in shared.js (function ciClassify) to match how your team writes comments.
After editing: chrome://extensions -> reload the extension -> refresh both tabs.
