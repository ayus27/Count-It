// Runs on count-it-pi.vercel.app: clicks the real +/- buttons for every queued change.
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const norm = (s) => s.toLowerCase().replace(/\s+/g, ' ').trim();

function findCard(id) {
  const cat = CI_CATS.find((c) => c.id === id);
  const el = [...document.querySelectorAll('h1,h2,h3,h4,p,span,div')].find((e) => {
    if (e.children.length) return false;
    const t = norm(e.textContent);
    return cat.x ? t === cat.m : t.startsWith(cat.m);
  });
  if (!el) return null;
  let p = el;
  while (p && p.querySelectorAll('button').length < 2) p = p.parentElement;
  if (!p) return null;
  const b = [...p.querySelectorAll('button')];
  const plus = b.find((x) => /^\s*\+\s*$/.test(x.textContent)) || b[b.length - 1];
  const minus = b.find((x) => /^\s*[−–-]\s*$/.test(x.textContent)) || b[0];
  return { plus, minus };
}

function setVal(el, v) {
  const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
  d.set.call(el, v); el.dispatchEvent(new Event('input', { bubbles: true }));
}
async function addVisitors(s) {
  const nameEl = document.querySelector('input[placeholder^="Student full name"]');
  const phoneEl = document.querySelector('input[placeholder^="Contact phone"]');
  const noteEl = document.querySelector('input[placeholder^="Notes"]');
  const addBtn = [...document.querySelectorAll('button')].find((b) => /^\s*Add\s*$/.test(b.textContent));
  if (!nameEl || !addBtn) return;
  const done = [];
  for (const v of s.vq.slice(0, 5)) {
    setVal(nameEl, v.name); if (phoneEl) setVal(phoneEl, v.phone || ''); if (noteEl) setVal(noteEl, v.note || '');
    await sleep(250); addBtn.click(); done.push(v.q); await sleep(350);
  }
  if (done.length) { const s2 = await ciLoad(); s2.vq = s2.vq.filter((x) => !done.includes(x.q)); await ciSave(s2); }
}

let busy = false;
setInterval(async () => {
  if (busy) return; busy = true;
  try {
    const s = await ciLoad();
    const done = [];
    for (const it of s.queue.slice(0, 25)) {
      const c = findCard(it.id);
      if (!c) continue;
      (it.d > 0 ? c.plus : c.minus).click();
      done.push(it.q);
      await sleep(120);
    }
    if (s.vq.length) await addVisitors(s);
    if (done.length) { const s2 = await ciLoad(); s2.queue = s2.queue.filter((x) => !done.includes(x.q)); await ciSave(s2); }
  } finally { busy = false; }
}, 1500);

// Welcome bubble + M-key mute on Count It
let CI_CFG = null;
(async () => {
  CI_CFG = await ciCfgLoad();
  if (!CI_CFG.welcome || !CI_CFG.feat.on) return;
  const u = (await chrome.storage.local.get('ci_user')).ci_user;
  const text = ciGreet(CI_CFG, CI_CFG.userName || u);
  if (text) ciBubble(text, CI_CFG, 5);
})();
chrome.storage.onChanged.addListener(async (ch) => { if (ch.ci_cfg) CI_CFG = await ciCfgLoad(); });
ciInstallMuteKey(() => CI_CFG, (msg) => ciBubble(msg, CI_CFG, 2));
