// ---- Categories (same as Count It). m = text to find the card on Count It; x = exact match
const CI_CATS = [
  { id: 'rec', l: 'Received', m: 'received', x: 1 },
  { id: 'nr', l: 'Not received', m: 'not received', x: 1 },
  { id: 'wrong', l: 'Wrong number', m: 'wrong number', x: 1 },
  { id: 'int', l: 'Interested', m: 'interested', x: 1 },
  { id: 'cb', l: 'Call back', m: 'call back', x: 1 },
  { id: 'fu', l: 'Interested but needs follow-up', m: 'interested but needs' },
  { id: 'par', l: 'Will discuss with parents', m: 'will discuss with pare' },
  { id: 'vis', l: 'Interested for visit tomorrow', m: 'interested for visit' },
  { id: 'ni', l: 'Not interested', m: 'not interested', x: 1 },
  { id: 'res', l: 'Turning up later (after results)', m: 'turning up later' },
  { id: 'av', l: 'Already visited the college', m: 'already visited the co' },
  { id: 'aj', l: 'Already joined another', m: 'already joined anoth' },
  { id: 'adm', l: 'Admitted', m: 'admitted', x: 1 },
  { id: 'cna', l: 'Course not available', m: 'course not available', x: 1 },
  { id: 'sch', l: 'Scholarship hesitation', m: 'scholarship related h' },
  { id: 'fee', l: 'Fees hesitation', m: 'fees related hesitation', x: 1 },
  { id: 'evt', l: 'Registered for event', m: 'registered for event', x: 1 },
  { id: 'cee', l: 'CEE (Medical)', m: 'cee', x: 1 }
];

// ---- Comment -> categories. Edit the regexes to match how your team writes comments.
function ciDefault(raw) {
  const t = ' ' + raw.toLowerCase().replace(/[\u2018\u2019]/g, "'").replace(/\s+/g, ' ') + ' ';
  const T = (r) => r.test(t);
  const cbk = T(/call (me )?(back|later|tomorrow|again)|callback|asked to call|call after/);
  const strong = T(/no answer|no response|unreachable|not reachable|switched? off|out of (coverage|reach|service)|\brnr\b|\bdnr\b|\bn\/r\b|not (pick|lift|attend|connect|respond|answer|reach|taking)|not rec[ei]+v|(did ?n[o']?t|didn't|did not|doesn't|does not|don't|do not|couldn't|could not|can't|cannot|unable to|never)\s+(\w+\s+)?(pick|lift|attend|answer|rec[ei]+v|respond|connect|reach)|block|barred|restricted|\bdnd\b|no incoming|call (failed|drop)|(customer|phone|number|user) (is )?not available|number (is )?(busy|off)/);
  const weak = !cbk && T(/\bbusy\b|ringing|\brang\b|disconnect|cut the call/);
  if (strong || weak) return ['nr'];

  const out = ['rec'];
  const ni = T(/not interested|no interest|don'?t want|do not want|refus|not willing|uninterested/);
  const aj = T(/already (joined|admitted|enrolled)(?! (in |at |with )?(us|iic))|joined (another|other|elsewhere|somewhere)|took admission (in|at) (another|other)/);
  const alreadyVisited = T(/already visited|visited (the )?(college|campus|iic)|came to (college|campus)/);
  const intr = !ni && T(/interest|want(s|ed)? (to know|more|info|details)|keen/);
  const vis = !alreadyVisited && T(/(will|wants? to|going to|plan(s|ning)? to) (visit|come)|visit(ing)? (tomorrow|college|campus|today)|(coming|come) (tomorrow|to college|today)/);
  const fu = intr && T(/follow.?up|think|consider|need(s)? time|get back/);

  if (T(/wrong (number|person|no)|not in use|number (does ?n'?t|not) exist|invalid number/)) out.push('wrong');
  if (ni) out.push('ni');
  if (intr && !fu && !vis) out.push('int');
  if (fu) out.push('fu');
  if (vis) out.push('vis');
  if (cbk) out.push('cb');
  if (T(/parent|father|mother|guardian|family|discuss with/)) out.push('par');
  if (T(/result|exam|waiting for|after (see|sle|neb|12|\+2|plus two)|not (yet )?out|pending/)) out.push('res');
  if (alreadyVisited) out.push('av');
  if (aj) out.push('aj');
  if (!aj && T(/\badmitted\b|admission (done|confirmed|completed)|took admission|enrolled (with|at|in) (us|iic)|joined (us|iic)/)) out.push('adm');
  if (T(/course (is )?not (available|offered)|not offered|don'?t have (the )?course/)) out.push('cna');
  if (T(/scholar/)) out.push('sch');
  if (T(/\bfees?\b|expensive|costly|afford|install?ment/)) out.push('fee');
  if (T(/regist(er|ered)|webinar|orientation|seminar|\bevent\b/)) out.push('evt');
  if (T(/\bcee\b|medical|mbbs|\bbds\b|nursing|pharmacy/)) out.push('cee');
  return out;
}

// ---- Shared storage (daily counts, per-lead record, queue that Count It consumes)
const CI_K = 'ci';
async function ciLoad() {
  const r = await chrome.storage.local.get(CI_K);
  let s = r[CI_K] || {};
  const d = new Date().toDateString();
  if (s.date !== d) s = { date: d, counts: {}, leads: {}, vis: {}, vlist: [], queue: s.queue || [], vq: s.vq || [], auto: s.auto !== false };
  s.counts = s.counts || {}; s.queue = s.queue || []; s.leads = s.leads || {}; s.vis = s.vis || {}; s.vlist = s.vlist || []; s.vq = s.vq || [];
  if (s.auto === undefined) s.auto = true;
  return s;
}
const ciSave = (s) => chrome.storage.local.set({ [CI_K]: s });
function ciApplyTo(s, deltas) {
  for (const [id, dl] of Object.entries(deltas)) {
    const cur = s.counts[id] || 0, n = Math.max(0, cur + dl);
    if (n === cur) continue;
    s.counts[id] = n;
    s.queue.push({ q: Date.now() + Math.random(), id, d: n - cur });
  }
}
async function ciAdjust(deltas) { const s = await ciLoad(); ciApplyTo(s, deltas); await ciSave(s); }
// Count a comment for one lead. Every call attempt is counted independently
// so that previously logged "Not received" calls are NOT subtracted when a call is connected.
async function ciApplyLead(key, ids) {
  const s = await ciLoad();
  const net = {};
  ids.forEach((i) => (net[i] = (net[i] || 0) + 1));
  ciApplyTo(s, net);
  if (key) s.leads[key] = ids;
  await ciSave(s);
  return { net, prev: null };
}
async function ciRevert(key, net, prev) {
  const s = await ciLoad();
  const inv = {}; Object.keys(net).forEach((k) => (inv[k] = -net[k]));
  ciApplyTo(s, inv);
  if (key) delete s.leads[key];
  await ciSave(s);
}

// ---- Taught rules: "when comment contains <phrase> -> count <category>" (always win over defaults)
function ciRuleHit(text, phrase) {
  let p = phrase.toLowerCase().trim(); if (!p) return false;
  const wild = p.endsWith('*'); if (wild) p = p.slice(0, -1);
  const esc = p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp('(^|[^a-z0-9])' + esc + (wild ? '' : '([^a-z0-9]|$)'), 'i').test(text.replace(/[\u2018\u2019]/g, "'"));
}
function ciClassify(raw, rules) {
  const hits = (rules || []).filter((r) => ciRuleHit(raw, r.p)).map((r) => r.id);
  if (hits.includes('ignore')) return [];
  const def = ciDefault(raw);
  if (!hits.length) return def;
  const primary = hits.includes('nr') ? 'nr' : hits.includes('rec') ? 'rec' : def[0];
  const subs = [...(def[0] === 'rec' ? def.slice(1) : []), ...hits.filter((h) => h !== 'rec' && h !== 'nr')];
  return [...new Set([primary, ...subs])];
}

// ---- Settings (taught rules + look & feel)
const CI_CFG_DEF = {
  rules: [], undoSecs: 5, visAuto: true, visCats: ['vis', 'cb'],
  greet: 'namaste', firstName: true, welcome: true, userName: '',
  feat: { on: true, fix: true, ai: false, period: true, enter: true, nfd: false, mute: true, ig: true, openBtn: true },
  igLabel: 'Reference', nfdNr: 1, nfdOther: 3, fixRules: [], remarks: [], aiKey: '',
  theme: { bg: '#ffffff', fg: '#111111', acc: '#16a34a', rad: 14, sh: 40, op: 100, fs: 13, w: 330, pos: 'br',
    pill: { bg: '', fg: '', bd: '', fs: 15, rad: 20, op: 100, showAuto: true, showCounts: true, x: null, y: null } }
};
async function ciCfgLoad() {
  const r = (await chrome.storage.local.get('ci_cfg')).ci_cfg || {}, rt = r.theme || {};
  return { ...CI_CFG_DEF, ...r, feat: { ...CI_CFG_DEF.feat, ...(r.feat || {}) }, theme: { ...CI_CFG_DEF.theme, ...rt, pill: { ...CI_CFG_DEF.theme.pill, ...(rt.pill || {}) } } };
}
const ciCfgSave = (c) => chrome.storage.local.set({ ci_cfg: c });

// ---- Interested visitors: queued here, typed into Count It's "Interested visitors" box
async function ciAddVisitor(v) {
  const s = await ciLoad();
  const k = (v.phone || v.name).toLowerCase();
  if (s.vis[k]) return false;               // already saved today
  s.vis[k] = 1; s.vlist.push({ name: v.name, phone: v.phone || '' });
  s.vq.push({ q: Date.now() + Math.random(), ...v });
  await ciSave(s);
  return true;
}

// ---- Greeting by the browser's local time (so it follows each person's time zone)
function ciGreet(cfg, name) {
  if (cfg.greet === 'off') return '';
  const h = new Date().getHours();
  const tg = h < 5 ? 'Good night' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 21 ? 'Good evening' : 'Good night';
  const n = name ? (cfg.firstName ? name.trim().split(/\s+/)[0] : name.trim()) : '';
  if (cfg.greet === 'time') return tg + (n ? ', ' + n : '') + '!';
  return (cfg.greet === 'hello' ? 'Hello' : 'Namaste 🙏') + (n ? ' ' + n : '') + '! ' + tg + '.';
}

// ---- Auto-corrector (offline). Fixes common typos, voice-typing slips, basic grammar, spacing, capitals.
const CI_VOICE = [['c will', 'CLMS'], ['see will', 'CLMS'], ['sea elms', 'CLMS'], ['see elms', 'CLMS'], ['c l m s', 'CLMS'], ['cl ms', 'CLMS'], ['c lms', 'CLMS'], ['i i c', 'IIC'], ['whats app', 'WhatsApp']];
const CI_TYPOS = {
  didnt: "didn't", dont: "don't", doesnt: "doesn't", cant: "can't", wont: "won't", wasnt: "wasn't", isnt: "isn't", arent: "aren't", havent: "haven't", hasnt: "hasn't",
  couldnt: "couldn't", wouldnt: "wouldn't", shouldnt: "shouldn't", im: "I'm", ive: "I've", thats: "that's", whats: "what's", didn: "didn't",
  recieve: 'receive', recieved: 'received', recive: 'receive', recived: 'received', reciving: 'receiving', receving: 'receiving', recevied: 'received', receieved: 'received',
  bussy: 'busy', busey: 'busy', tomorow: 'tomorrow', tommorow: 'tomorrow', tomarrow: 'tomorrow', tommarow: 'tomorrow', tomorrw: 'tomorrow', tmrw: 'tomorrow',
  wil: 'will', wll: 'will', hav: 'have', pls: 'please', plz: 'please', abt: 'about', intrested: 'interested', intersted: 'interested', interesed: 'interested', interestd: 'interested', intrest: 'interest',
  admision: 'admission', admisson: 'admission', addmission: 'admission', admited: 'admitted', colege: 'college', colage: 'college', collage: 'college', scholorship: 'scholarship', scolarship: 'scholarship', scholarshipp: 'scholarship',
  corse: 'course', paretns: 'parents', parnets: 'parents', parrents: 'parents', familly: 'family', discus: 'discuss', dicuss: 'discuss', discusing: 'discussing', discussng: 'discussing',
  visting: 'visiting', vist: 'visit', visitng: 'visit', comming: 'coming', wating: 'waiting', waitng: 'waiting', reslt: 'result', reasult: 'result', resut: 'result', resuts: 'results',
  informtion: 'information', infromation: 'information', infomation: 'information', numbr: 'number', nuber: 'number', unreachble: 'unreachable', unreacheable: 'unreachable',
  swiched: 'switched', swithced: 'switched', swtiched: 'switched', wich: 'which', becuase: 'because', becasue: 'because', definately: 'definitely', defintely: 'definitely', alot: 'a lot',
  thier: 'their', teh: 'the', adn: 'and', taht: 'that', wnat: 'want', wnats: 'wants', knw: 'know', shoud: 'should', cuold: 'could', woud: 'would', beacuse: 'because',
  gradute: 'graduate', gradution: 'graduation', facutly: 'faculty', sceince: 'science', mangement: 'management', cource: 'course', cources: 'courses', feee: 'fee', fess: 'fees',
  phne: 'phone', phon: 'phone', calld: 'called', calling: 'calling', pickd: 'picked', pikced: 'picked', anwser: 'answer', answr: 'answer', ansered: 'answered', respnd: 'respond', responce: 'response'
};
const CI_COMMON = /^(said|say|says|will|free|call|called|busy|was|not|but|then|come|coming|visit|want|wants|told|later|number|phone|college|course|fees|parents|result|results|they|the|and|for|with|this|that)$/i;
const CI_UPPER = ['clms', 'iic', 'cee', 'nfd', 'tvd', 'mbbs', 'bds', 'bba', 'bbm', 'bbs', 'sms', 'otp'];
function ciFixText(raw, cfg) {
  let t = String(raw).replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"').trim();
  const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
  const rules = [...CI_VOICE.map(([p, r]) => ({ p, r })), ...((cfg && cfg.fixRules) || [])];
  rules.forEach((x) => { t = t.replace(new RegExp('(^|[^A-Za-z0-9])' + esc(x.p) + '(?![A-Za-z0-9])', 'gi'), (m, a) => a + x.r); });
  t = t.replace(/[A-Za-z]+(?:'[A-Za-z]+)?/g, (w) => {
    const k = w.toLowerCase(); let r = CI_TYPOS[k];
    if (!r) return CI_UPPER.includes(k) ? k.toUpperCase() : (w.length >= 3 && w === w.toUpperCase() && CI_COMMON.test(w) ? k : w);
    if (w[0] !== w[0].toLowerCase() && r[0] !== 'I') r = r[0].toUpperCase() + r.slice(1);
    return r;
  });
  t = t.replace(/\b(he|she|it) (don't|do not)\b/gi, '$1 doesn\'t').replace(/\b(i|you|we|they) doesn't\b/gi, '$1 don\'t')
    .replace(/\b(should|could|would|must) of\b/gi, '$1 have').replace(/\bi has\b/gi, 'I have').replace(/\b(he|she) have\b/gi, '$1 has')
    .replace(/\b(he|she) were\b/gi, '$1 was')
    .replace(/\ba\s+([aeio][a-z]*)/gi, (m, w) => (/^(one|once|eu)/i.test(w) ? m : (m[0] === 'A' ? 'An ' : 'an ') + w))
    .replace(/\b([A-Za-z]{2,})\s+\1\b/gi, (m, w) => (/^(had|that|very|bye)$/i.test(w) ? m : w));
  t = t.replace(/[ \t]+/g, ' ').replace(/\s+([,.!?;:])/g, '$1').replace(/,(?=[A-Za-z])/g, ', ').replace(/\bi\b/g, 'I');
  t = t.replace(/\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday|january|february|april|june|july|august|september|october|november|december)\b/gi, (m) => m[0].toUpperCase() + m.slice(1).toLowerCase());
  t = t.replace(/(^|[.!?]\s+|\n\s*)([a-z])/g, (m, a, c) => a + c.toUpperCase());
  if (!cfg || !cfg.feat || cfg.feat.period !== false) { if (/[A-Za-z0-9)]$/.test(t)) t += '.'; }
  return t;
}

// ---- Small on-page bubble (used on Count It) and the M-key mute shortcut
function ciBubble(text, cfg, secs) {
  const h = document.createElement('div'), r = h.attachShadow({ mode: 'open' }), t = cfg.theme, b = document.createElement('div');
  b.textContent = text;
  b.style.cssText = `position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:2147483647;font:600 ${t.fs + 2}px system-ui,sans-serif;padding:12px 20px;border-radius:${t.rad}px;background:${t.bg};color:${t.fg};border:1px solid ${t.fg}33;border-left:4px solid ${t.acc};box-shadow:0 6px ${t.sh * 0.5}px rgba(0,0,0,${t.sh / 220})`;
  r.appendChild(b); document.documentElement.appendChild(h);
  setTimeout(() => h.remove(), (secs || 5) * 1000);
}
function ciInstallMuteKey(getCfg, notify) {
  addEventListener('keydown', (e) => {
    const c = getCfg(); if (!c || !c.feat.on || !c.feat.mute) return;
    if ((e.key || '').toLowerCase() !== 'm' || e.metaKey || e.ctrlKey || e.altKey || e.shiftKey || e.repeat || e.isComposing) return;
    const t = e.composedPath()[0];
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    try { chrome.runtime.sendMessage({ toggleMute: true }, (r) => { if (!chrome.runtime.lastError) notify(r && r.muted ? '🔇 Sound muted' : '🔊 Sound on'); }); } catch (x) {}
  }, true);
}
