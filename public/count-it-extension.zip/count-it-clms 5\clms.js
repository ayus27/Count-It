// Runs on CLMS: floating tally panel, taught rules, theme settings, auto-count.
(async function () {
  let cfg = await ciCfgLoad();
  let tab = 'tally', lastUndo = null;
  const host = document.createElement('div');
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>
  *{box-sizing:border-box;font-family:system-ui,sans-serif}
  :host{position:fixed;z-index:2147483647;font-size:var(--fs)}
  #w{display:flex;flex-direction:column;position:relative}
  :host([data-v=top]) #w{flex-direction:column-reverse}
  :host([data-h=left]) #w{align-items:flex-start}:host([data-h=right]) #w{align-items:flex-end}
  .pill,.panel,.toast{background:color-mix(in srgb,var(--bg) var(--op),transparent);color:var(--fg);border:1px solid color-mix(in srgb,var(--fg) 18%,transparent);box-shadow:0 6px calc(var(--sh)*.5px) rgba(0,0,0,calc(var(--sh)/220))}
  .pill{padding:10px 16px;font-weight:600;cursor:pointer;user-select:none;touch-action:none;text-align:center;white-space:nowrap;font-size:var(--pfs);border-radius:var(--prad);background:color-mix(in srgb,var(--pbg) var(--pop),transparent);color:var(--pfg);border-color:var(--pbd)}
  .top{position:sticky;top:0;background:var(--bg);z-index:2;border-radius:var(--rad) var(--rad) 0 0}
  .gr{padding:0 14px 8px;font-weight:600}
  .panel{display:none;width:var(--w);max-height:70vh;overflow:auto;border-radius:var(--rad);margin:8px 0}
  .open .panel{display:block}
  .hd{display:flex;justify-content:space-between;align-items:center;padding:12px 14px 6px;gap:6px;flex-wrap:wrap}
  .tabs{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;padding:0 14px 8px;border-bottom:1px solid color-mix(in srgb,var(--fg) 12%,transparent)}
  .tabs button{border:0;border-radius:8px;padding:5px 2px;font-size:.82em;cursor:pointer;background:color-mix(in srgb,var(--fg) 8%,transparent);color:var(--fg);font-weight:600}
  .tabs button.a{background:var(--acc);color:#fff}
  .lk{border:0;border-radius:8px;padding:6px 10px;cursor:pointer;font-weight:700;font-size:.95em;background:color-mix(in srgb,var(--fg) 10%,transparent);color:var(--fg)}
  .sw{border:0;border-radius:999px;padding:6px 14px;font-weight:700;font-size:.9em;cursor:pointer}
  .on{background:var(--acc);color:#fff}.off{background:color-mix(in srgb,var(--fg) 14%,transparent);color:var(--fg)}
  .row{display:flex;align-items:center;gap:8px;padding:7px 14px;border-bottom:1px solid color-mix(in srgb,var(--fg) 8%,transparent)}
  .row.big{font-size:1.15em;font-weight:700;padding:10px 14px;background:color-mix(in srgb,var(--fg) 6%,transparent)}
  .row span.l{flex:1}.row b{min-width:28px;text-align:center;font-size:1.2em}
  .row button{width:28px;height:28px;border-radius:8px;border:0;cursor:pointer;font-size:16px;font-weight:700}
  .m{background:color-mix(in srgb,var(--fg) 14%,transparent);color:var(--fg)}.p{background:var(--acc);color:#fff}
  .sec{padding:10px 14px;display:flex;flex-direction:column;gap:8px}
  .hint{font-size:.9em;opacity:.65}
  input,select{width:100%;padding:7px 9px;border-radius:8px;border:1px solid color-mix(in srgb,var(--fg) 25%,transparent);background:transparent;color:var(--fg);font-size:1em}
  input[type=checkbox]{width:auto}textarea{width:100%;padding:7px 9px;border-radius:8px;border:1px solid color-mix(in srgb,var(--fg) 25%,transparent);background:transparent;color:var(--fg);font-size:1em;font-family:inherit}input[type=color]{padding:0;height:32px}input[type=range]{padding:0}
  .btn{border:0;border-radius:8px;padding:7px 12px;cursor:pointer;background:var(--acc);color:#fff;font-weight:700}
  .btn.g{background:color-mix(in srgb,var(--fg) 14%,transparent);color:var(--fg)}
  .rule{display:flex;justify-content:space-between;gap:8px;align-items:center;padding:5px 8px;border-radius:8px;background:color-mix(in srgb,var(--fg) 6%,transparent)}
  .rule button{border:0;background:none;color:var(--fg);cursor:pointer;font-size:15px}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:8px;align-items:center}
  .toast{position:absolute;bottom:56px;border-radius:10px;padding:12px 14px;display:none;width:300px;border-left:4px solid var(--acc)}
  :host([data-v=top]) .toast{bottom:auto;top:56px}
  :host([data-h=right]) .toast{right:0}:host([data-h=left]) .toast{left:0}
  .toast button{margin-left:8px;border:0;background:var(--fg);color:var(--bg);border-radius:6px;padding:4px 12px;cursor:pointer}
  </style><div class="toast" id="t"></div><div id="w"><div class="panel" id="pn"><div class="top"><div class="hd" id="hd"></div><div class="gr" id="gr"></div><div class="tabs" id="tb"></div></div><div id="bd"></div></div><div class="pill" id="pl"></div></div>`;
  document.documentElement.appendChild(host);
  const $ = (id) => root.getElementById(id);
  const nameOf = (id) => (id === 'ignore' ? 'Ignore (count nothing)' : CI_CATS.find((c) => c.id === id).l);
  const esc = (x) => String(x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function applyTheme() {
    const t = cfg.theme, p = t.pill, st = host.style;
    const vars = { bg: t.bg, fg: t.fg, acc: t.acc, rad: t.rad + 'px', sh: t.sh, op: t.op + '%', fs: t.fs + 'px', w: t.w + 'px',
      pbg: p.bg || t.bg, pfg: p.fg || t.fg, pbd: p.bd || `color-mix(in srgb,${t.fg} 18%,transparent)`, pfs: p.fs + 'px', prad: p.rad + 'px', pop: p.op + '%' };
    for (const k in vars) st.setProperty('--' + k, vars[k]);
    st.top = st.bottom = st.left = st.right = 'auto';
    const pr = $('pl').getBoundingClientRect(), pw = pr.width || 170, ph = pr.height || 40;
    let v, h;
    if (p.x != null && p.y != null) {                 // free (dragged) position
      const x = Math.min(Math.max(0, p.x), Math.max(0, innerWidth - pw)), y = Math.min(Math.max(0, p.y), Math.max(0, innerHeight - ph));
      v = y + ph / 2 > innerHeight / 2 ? 'bottom' : 'top'; h = x + pw / 2 > innerWidth / 2 ? 'right' : 'left';
      st[v] = (v === 'top' ? y : innerHeight - y - ph) + 'px'; st[h] = (h === 'left' ? x : innerWidth - x - pw) + 'px';
    } else {                                           // corner preset
      v = t.pos[0] === 't' ? 'top' : 'bottom'; h = t.pos[1] === 'l' ? 'left' : 'right';
      st[v] = '16px'; st[h] = '16px';
    }
    host.dataset.v = v; host.dataset.h = h;
  }
  const saveCfg = () => ciCfgSave(cfg);

  // ---------- pill + header + tabs
  let S = await ciLoad(), cachedName = (await chrome.storage.local.get('ci_user')).ci_user || '';
  const uName = () => cfg.userName || cachedName;
  function updatePill() {
    const c = S.counts, rec = c.rec || 0, nr = c.nr || 0;
    const pc = cfg.theme.pill;
    $('pl').textContent = (pc.showAuto ? (S.auto ? '● AUTO  ' : '○ MANUAL  ') : '') + (pc.showCounts ? `✓ ${rec}  ✗ ${nr}  · ${rec + nr} calls` : 'Count It');
    $('gr').textContent = ciGreet(cfg, uName()); $('gr').style.display = $('gr').textContent ? 'block' : 'none';
    $('hd').innerHTML = `${cfg.feat.openBtn ? '<button class="lk" id="oc" title="Open Count It in a new tab">↗ Open Count It</button>' : ''}${cfg.feat.ig ? `<button class="lk" id="ig">${esc(cfg.igLabel)}</button>` : ''}<button class="sw ${S.auto ? 'on' : 'off'}" id="au">Auto-count: ${S.auto ? 'ON' : 'OFF'}</button>`;
    if ($('oc')) $('oc').onclick = () => {
      try { chrome.runtime.sendMessage({ openCountIt: true }); } catch (e) { window.open('https://count-it-pi.vercel.app/', '_blank'); }
    };
    if ($('ig')) $('ig').onclick = () => {
      const url = 'https://www.instagram.com/';
      try { chrome.runtime.sendMessage({ openExtra: true, url }); } catch (e) { window.open(url, '_blank', 'popup,width=430,height=820'); }
    };
    $('au').onclick = async () => { const s2 = await ciLoad(); s2.auto = !s2.auto; await ciSave(s2); };
    $('tb').innerHTML = [['tally', 'Tally'], ['teach', 'Teach'], ['fix', 'Fix'], ['rem', 'Remarks'], ['date', 'Dates'], ['vis', 'Visitors'], ['style', 'Style'], ['sw', 'Switches']].map(([k, l]) => `<button data-k="${k}" class="${tab === k ? 'a' : ''}">${l}</button>`).join('');
    root.querySelectorAll('.tabs button').forEach((b) => (b.onclick = () => { tab = b.dataset.k; updatePill(); renderBody(); }));
  }

  // ---------- tabs
  function renderBody() {
    if (tab === 'tally') return tallyTab();
    if (tab === 'teach') return teachTab();
    if (tab === 'vis') return visTab();
    if (tab === 'fix') return fixTab();
    if (tab === 'rem') return remTab();
    if (tab === 'date') return dateTab();
    if (tab === 'sw') return swTab();
    styleTab();
  }
  function tallyTab() {
    const c = S.counts, rec = c.rec || 0, nr = c.nr || 0, tot = rec + nr;
    $('bd').innerHTML = (lastUndo ? '<div class="sec"><button class="btn g" id="ul">↶ Undo last auto-count</button></div>' : '') +
      CI_CATS.map((k, i) => `<div class="row ${i < 2 ? 'big' : ''}"><span class="l">${k.l}</span><button class="m" data-i="${k.id}" data-d="-1">−</button><b>${c[k.id] || 0}</b><button class="p" data-i="${k.id}" data-d="1">+</button></div>`).join('') +
      `<div class="sec hint">Pick-up rate: ${tot ? Math.round((rec / tot) * 100) : 0}% (${rec} of ${tot})</div>`;
    root.querySelectorAll('.row button').forEach((b) => (b.onclick = () => ciAdjust({ [b.dataset.i]: +b.dataset.d })));
    if (lastUndo) $('ul').onclick = () => { lastUndo(); lastUndo = null; };
  }
  async function visTab() {
    const s = await ciLoad(), last = (await chrome.storage.local.get('ci_last')).ci_last || {};
    const opts = [['vis', 'Interested for visit tomorrow'], ['cb', 'Call back'], ['fu', 'Interested but needs follow-up'], ['int', 'Interested'], ['par', 'Will discuss with parents'], ['res', 'Turning up later']];
    $('bd').innerHTML = `<div class="sec">
      <div class="hint">Students to call tomorrow / day after. They are typed into the <b>Interested visitors</b> box in Count It for you (needs the Count It tab open).</div>
      <label class="hint"><input type="checkbox" id="va" ${cfg.visAuto ? 'checked' : ''}> Auto-add the student when a comment counts as:</label>
      ${opts.map(([k, l]) => `<label class="hint"><input type="checkbox" data-vc="${k}" ${cfg.visCats.includes(k) ? 'checked' : ''}> ${l}</label>`).join('')}
      <div class="hint"><b>Add by hand</b></div>
      <input id="vn" placeholder="Student full name *"><input id="vp" placeholder="Contact phone (optional)"><input id="vo" placeholder="Notes / interested course">
      <div class="two"><button class="btn g" id="vf">Fill from last comment</button><button class="btn" id="vb">Add to Count It</button></div>
      <div class="hint" id="vm"></div>
      <div class="hint"><b>Added today (${s.vlist.length})</b></div>
      ${s.vlist.map((v) => `<div class="rule"><span>${esc(v.name)} ${v.phone ? '· ' + esc(v.phone) : ''}</span></div>`).join('')}</div>`;
    $('va').onchange = (e) => { cfg.visAuto = e.target.checked; saveCfg(); };
    root.querySelectorAll('[data-vc]').forEach((el) => (el.onchange = () => {
      cfg.visCats = [...root.querySelectorAll('[data-vc]')].filter((x) => x.checked).map((x) => x.dataset.vc); saveCfg();
    }));
    $('vf').onclick = () => { $('vn').value = last.name || ''; $('vp').value = last.phone || ''; $('vo').value = (last.t || '').slice(0, 100); };
    $('vb').onclick = async () => {
      const name = $('vn').value.trim(); if (!name) return ($('vm').textContent = 'Please enter the student name.');
      const ok = await ciAddVisitor({ name, phone: $('vp').value.trim(), note: $('vo').value.trim() });
      $('vm').textContent = ok ? 'Added. It will appear in Count It within a few seconds.' : 'Already added today.';
      if (ok) setTimeout(visTab, 900);
    };
  }
  // ---------- page helpers (comment box, dates)
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const press = (el) => ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach((t) => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d; };
  const visible = (e) => e && e.offsetParent !== null && !host.contains(e);
  function findBox(from) {
    let p = from;
    for (let i = 0; i < 9 && p; i++, p = p.parentElement) {
      const f = [...p.querySelectorAll('textarea,[contenteditable=""],[contenteditable="true"]')].filter(visible);
      if (f.length) return f[0];
    }
    return null;
  }
  const findSendBtn = (from) => {
    let p = from;
    for (let i = 0; i < 9 && p; i++, p = p.parentElement) {
      const b = [...p.querySelectorAll('button,[role=button]')].find((x) => /^\s*(send|post)\s*$/i.test(x.innerText) && visible(x));
      if (b) return b;
    }
    return null;
  };
  const readBox = (el) => (el.value !== undefined ? el.value : el.innerText) || '';
  function writeBox(el, text) {
    el.focus();
    if (el.value !== undefined) {
      Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set.call(el, text);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      document.execCommand('selectAll', false, null);
      if (!document.execCommand('insertText', false, text)) { el.textContent = text; el.dispatchEvent(new Event('input', { bubbles: true })); }
    }
  }
  function findDateInput(kind) {
    const rx = kind === 'NFD' ? /next follow.?up date|\(NFD\)/i : /tentative visit date|\(TVD\)/i;
    const labels = [...document.querySelectorAll('label,span,div,p')].filter((e) => e.children.length === 0 && rx.test(e.textContent) && visible(e));
    for (const l of labels) { let p = l; for (let i = 0; i < 4 && p; i++) { p = p.parentElement; const inp = p && p.querySelector('input'); if (inp && !host.contains(inp)) return inp; } }
    return null;
  }
  const MRX = new RegExp('^(' + MONTHS.join('|') + ')\\s*(\\d{4})$', 'i');
  function headerEl() {
    const c = [...document.querySelectorAll('div,span,button,th,p,h1,h2,h3,h4')].filter((e) => visible(e) && e.textContent.length < 25 && MRX.test(e.textContent.trim().replace(/\s+/g, ' ')));
    return c.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)[0] || null;
  }
  function arrowEls(hdr) {
    let root = hdr.parentElement;
    for (let i = 0; i < 3 && root; i++, root = root.parentElement) {
      const els = [...root.querySelectorAll('button,[role=button],svg,i,img')].filter((el) => !hdr.contains(el) && !el.contains(hdr)).map((el) => el.closest('button,[role=button]') || el);
      const u = [...new Set(els)].filter((el) => el.textContent.trim().length < 2);
      if (u.length >= 2) return u;
    }
    return [];
  }
  const dayLeaves = (p) => [...p.querySelectorAll('*')].filter((e) => e.children.length === 0 && /^\d{1,2}$/.test(e.textContent.trim()) && +e.textContent >= 1 && +e.textContent <= 31);
  async function pickDate(input, d) {
    input.scrollIntoView({ block: 'center' }); input.focus(); press(input); await sleep(400);
    for (let n = 0; n < 24; n++) {
      const hdr = headerEl(); if (!hdr) return false;
      const m = hdr.textContent.trim().replace(/\s+/g, ' ').match(MRX);
      const cur = +m[2] * 12 + MONTHS.findIndex((x) => x.toLowerCase() === m[1].toLowerCase()), want = d.getFullYear() * 12 + d.getMonth();
      if (cur === want) break;
      const ar = arrowEls(hdr); if (ar.length < 2) return false;
      press(cur < want ? ar[ar.length - 1] : ar[0]); await sleep(200);
    }
    const hdr = headerEl(); if (!hdr) return false;
    let root = hdr; for (let i = 0; i < 6 && root; i++) { root = root.parentElement; if (root && dayLeaves(root).length >= 28) break; }
    if (!root) return false;
    const all = dayLeaves(root), day = d.getDate();
    const cand = all.filter((e, i) => +e.textContent === day && !(day > 20 && i < 10) && !(day < 14 && i >= all.length - 14));
    if (!cand.length) return false;
    press(cand[0].closest('td,button,[role=gridcell],[role=button]') || cand[0]); await sleep(300);
    return !!input.value || !headerEl();
  }
  async function setDate(kind, d) {
    const inp = findDateInput(kind);
    if (!inp) return `Could not find the ${kind} box – open a lead first.`;
    const ok = await pickDate(inp, d);
    return ok ? `${kind} set to ${d.toDateString()}.` : `Could not set ${kind} automatically – please pick it by hand.`;
  }
  async function autoNfd(text) {
    const inp = findDateInput('NFD'); if (!inp || inp.value) return;
    await pickDate(inp, addDays(ciClassify(text, cfg.rules).includes('nr') ? cfg.nfdNr : cfg.nfdOther));
  }

  // ---------- Fix tab
  function fixTab() {
    const f = cfg.feat;
    $('bd').innerHTML = `<div class="sec">
      <label class="hint"><input type="checkbox" data-f="fix" ${f.fix ? 'checked' : ''}> Auto-correct my comment when I press Send</label>
      <label class="hint"><input type="checkbox" data-f="period" ${f.period ? 'checked' : ''}> Add a full stop at the end</label>
      <label class="hint"><input type="checkbox" data-f="ai" ${f.ai ? 'checked' : ''}> AI mode: understands context (needs your Anthropic key)</label>
      <label class="hint">Anthropic API key (stored only in this browser; sent only to api.anthropic.com)<input type="password" id="ak" value="${esc(cfg.aiKey)}" placeholder="sk-ant-..."></label>
      <div class="hint"><b>Voice-typing fixes:</b> when the Mac mishears a word, teach the right one.</div>
      <div class="two"><input id="fp" placeholder="heard: c will"><input id="fr" placeholder="should be: CLMS"></div>
      <button class="btn" id="fa">Add fix</button>
      ${cfg.fixRules.map((r, i) => `<div class="rule"><span>“${esc(r.p)}” → <b>${esc(r.r)}</b></span><button data-i="${i}">✕</button></div>`).join('')}
      <div class="hint"><b>Try it</b> (built-in corrector):</div>
      <textarea id="ft" rows="2" placeholder="type a messy comment"></textarea><div id="fo" class="hint"></div></div>`;
    root.querySelectorAll('[data-f]').forEach((el) => (el.onchange = () => { cfg.feat[el.dataset.f] = el.checked; saveCfg(); }));
    $('ak').oninput = (e) => { cfg.aiKey = e.target.value.trim(); saveCfg(); };
    $('fa').onclick = () => { const p = $('fp').value.trim(), r = $('fr').value.trim(); if (!p || !r) return; cfg.fixRules.push({ p, r }); saveCfg(); fixTab(); };
    root.querySelectorAll('.rule button').forEach((b) => (b.onclick = () => { cfg.fixRules.splice(+b.dataset.i, 1); saveCfg(); fixTab(); }));
    $('ft').oninput = (e) => { $('fo').textContent = e.target.value.trim() ? '→ ' + ciFixText(e.target.value, cfg) : ''; };
  }

  // ---------- Remarks tab (saved remarks you can paste with one click)
  function remTab() {
    $('bd').innerHTML = `<div class="sec">
      <div class="hint">Save remarks you use often. Click one to put it in the comment box of the lead that is open.</div>
      <textarea id="rn" rows="2" placeholder="type a remark to save"></textarea>
      <div class="two"><button class="btn" id="ra">Save remark</button><button class="btn g" id="rb">Save what’s in the comment box</button></div>
      <div class="hint" id="rm"></div>
      ${cfg.remarks.length ? cfg.remarks.map((r, i) => `<div class="rule"><span data-u="${i}" style="cursor:pointer;flex:1">${esc(r)}</span><button data-i="${i}">✕</button></div>`).join('') : '<div class="hint">No saved remarks yet.</div>'}</div>`;
    const box = () => { const s = [...document.querySelectorAll('button,[role=button]')].find((x) => /^\s*(send|post)\s*$/i.test(x.innerText) && visible(x)); return s ? findBox(s) : null; };
    $('ra').onclick = () => { const v = $('rn').value.trim(); if (v) { cfg.remarks.push(v); saveCfg(); remTab(); } };
    $('rb').onclick = () => { const b = box(), v = b ? readBox(b).trim() : ''; if (v) { cfg.remarks.push(v); saveCfg(); remTab(); } else $('rm').textContent = 'No comment box with text found – open a lead and type first.'; };
    root.querySelectorAll('.rule button').forEach((b) => (b.onclick = () => { cfg.remarks.splice(+b.dataset.i, 1); saveCfg(); remTab(); }));
    root.querySelectorAll('[data-u]').forEach((el) => (el.onclick = async () => {
      const text = cfg.remarks[+el.dataset.u], b = box();
      if (b) { const cur = readBox(b).trim(); writeBox(b, cur ? cur + ' ' + text : text); $('rm').textContent = 'Inserted.'; }
      else { try { await navigator.clipboard.writeText(text); } catch (e) {} $('rm').textContent = 'No comment box open – copied to clipboard instead.'; }
    }));
  }

  // ---------- Dates tab
  function dateTab() {
    const btns = (k) => [['Tomorrow', 1], ['+2 days', 2], ['+3 days', 3], ['+1 week', 7]].map(([l, n]) => `<button class="btn g" data-k="${k}" data-n="${n}">${l}</button>`).join('');
    $('bd').innerHTML = `<div class="sec">
      <div class="hint">Fills the date boxes in the comment section of the lead that is open.</div>
      <div class="hint"><b>Next Follow Up Date (NFD)</b></div><div class="two">${btns('NFD')}</div>
      <div class="hint"><b>Tentative Visit Date (TVD)</b></div><div class="two">${btns('TVD')}</div>
      <div class="hint">Pick any date</div><input type="date" id="dc">
      <div class="two"><button class="btn" id="dn">Set as NFD</button><button class="btn" id="dt">Set as TVD</button></div>
      <div class="hint" id="dm"></div>
      <div class="hint"><b>Auto-assign</b></div>
      <label class="hint"><input type="checkbox" data-f="nfd" ${cfg.feat.nfd ? 'checked' : ''}> Set NFD automatically when I press Send (only if it is empty)</label>
      <div class="two"><label class="hint">Not received: +<input type="number" id="n1" min="0" max="60" value="${cfg.nfdNr}"> days</label><label class="hint">Everything else: +<input type="number" id="n2" min="0" max="60" value="${cfg.nfdOther}"> days</label></div></div>`;
    const run = async (k, d) => { $('dm').textContent = 'Working…'; $('w').classList.remove('open'); const msg = await setDate(k, d); $('w').classList.add('open'); $('dm').textContent = msg; };
    root.querySelectorAll('[data-n]').forEach((b) => (b.onclick = () => run(b.dataset.k, addDays(+b.dataset.n))));
    const custom = (k) => { const v = $('dc').value; if (!v) return ($('dm').textContent = 'Pick a date first.'); const [y, m, d] = v.split('-').map(Number); run(k, new Date(y, m - 1, d)); };
    $('dn').onclick = () => custom('NFD'); $('dt').onclick = () => custom('TVD');
    root.querySelectorAll('[data-f]').forEach((el) => (el.onchange = () => { cfg.feat[el.dataset.f] = el.checked; saveCfg(); }));
    $('n1').oninput = (e) => { cfg.nfdNr = +e.target.value || 0; saveCfg(); }; $('n2').oninput = (e) => { cfg.nfdOther = +e.target.value || 0; saveCfg(); };
  }

  // ---------- Switches tab: turn anything off
  function swTab() {
    const rows = [['on', 'Everything (master switch)'], ['fix', 'Auto-correct spelling & grammar'], ['ai', 'AI mode for the corrector'], ['period', 'Full stop at the end'], ['enter', 'Also work when I press Enter to send'],
      ['nfd', 'Auto-set NFD date on Send'], ['mute', 'M key mutes / unmutes sound'], ['ig', 'Show the extra button'], ['openBtn', 'Show “Open Count It” button']];
    $('bd').innerHTML = `<div class="sec">
      ${rows.map(([k, l]) => `<label class="hint"><input type="checkbox" data-f="${k}" ${cfg.feat[k] ? 'checked' : ''}> ${l}</label>`).join('')}
      <label class="hint"><input type="checkbox" id="sa" ${S.auto ? 'checked' : ''}> Auto-count calls from my comments</label>
      <label class="hint"><input type="checkbox" id="sv" ${cfg.visAuto ? 'checked' : ''}> Auto-add interested visitors</label>
      <label class="hint"><input type="checkbox" id="sw" ${cfg.welcome ? 'checked' : ''}> Welcome popup</label>
      <label class="hint">Name of the extra button<input data-ck="igLabel" value="${esc(cfg.igLabel)}"></label>
      <div class="hint">M works only on CLMS / Count It pages while you are not typing in a box. It mutes every browser tab, not the whole Mac.</div></div>`;
    root.querySelectorAll('[data-f]').forEach((el) => (el.onchange = () => { cfg.feat[el.dataset.f] = el.checked; saveCfg(); updatePill(); }));
    root.querySelector('[data-ck=igLabel]').oninput = (e) => { cfg.igLabel = e.target.value || 'Reference'; saveCfg(); updatePill(); };
    $('sa').onchange = async (e) => { const s2 = await ciLoad(); s2.auto = e.target.checked; await ciSave(s2); };
    $('sv').onchange = (e) => { cfg.visAuto = e.target.checked; saveCfg(); };
    $('sw').onchange = (e) => { cfg.welcome = e.target.checked; saveCfg(); };
  }

  async function teachTab() {
    const last = (await chrome.storage.local.get('ci_last')).ci_last;
    $('bd').innerHTML = `<div class="sec">
      <div class="hint"><b>Teach me:</b> when a comment contains this word/phrase, count this category. Your rules beat the defaults. Add * at the end for a wildcard (rec* matches rec, recd, receive…).</div>
      <input id="tp" placeholder="e.g. rcv  or  no rng">
      <select id="tc">${CI_CATS.map((k) => `<option value="${k.id}">${k.l}</option>`).join('')}<option value="ignore">Ignore (count nothing)</option></select>
      <button class="btn" id="ta">Add rule</button>
      ${last ? `<div class="hint">Your last comment: “${esc(last.t.slice(0, 80))}”</div>` : ''}
      <div id="rl">${cfg.rules.length ? cfg.rules.map((r, i) => `<div class="rule"><span>“${esc(r.p)}” → <b>${esc(nameOf(r.id))}</b></span><button data-i="${i}">✕</button></div>`).join('') : '<div class="hint">No taught rules yet.</div>'}</div>
      <div class="hint"><b>Test a comment</b> – see what it would count:</div>
      <input id="tt" placeholder="type a sample comment"><div id="tr" class="hint"></div></div>`;
    $('ta').onclick = () => { const p = $('tp').value.trim(); if (!p) return; cfg.rules.push({ p, id: $('tc').value }); saveCfg(); teachTab(); };
    root.querySelectorAll('.rule button').forEach((b) => (b.onclick = () => { cfg.rules.splice(+b.dataset.i, 1); saveCfg(); teachTab(); }));
    $('tt').oninput = (e) => {
      const v = e.target.value.trim(); if (!v) return ($('tr').textContent = '');
      const ids = ciClassify(v, cfg.rules);
      $('tr').innerHTML = ids.length ? 'Would count: <b>' + ids.map(nameOf).join(' + ') + '</b>' : 'Would count: <b>nothing (ignored)</b>';
    };
  }
  const PRESETS = { Light: ['#ffffff', '#111111', '#16a34a'], Soft: ['#f5f1ea', '#2b2b2b', '#d97706'], Blue: ['#eef4ff', '#0f172a', '#2563eb'], Dark: ['#1e1e1e', '#f5f5f5', '#22c55e'] };
  function styleTab() {
    const t = cfg.theme, p = t.pill;
    const rg = (att, o, k, l, mn, mx) => `<label class="hint">${l}: <span id="v_${att}${k}">${o[k]}</span><input type="range" data-${att}="${k}" min="${mn}" max="${mx}" value="${o[k]}"></label>`;
    const cb = (att, o, k, l) => `<label class="hint"><input type="checkbox" data-${att}="${k}" ${o[k] ? 'checked' : ''}> ${l}</label>`;
    $('bd').innerHTML = `<div class="sec">
      <div class="hint"><b>Panel look</b></div>
      <div class="two">${Object.keys(PRESETS).map((n) => `<button class="btn g" data-p="${n}">${n}</button>`).join('')}</div>
      <div class="two"><label class="hint">Background<input type="color" data-k="bg" value="${t.bg}"></label><label class="hint">Text<input type="color" data-k="fg" value="${t.fg}"></label></div>
      <label class="hint">Accent / buttons<input type="color" data-k="acc" value="${t.acc}"></label>
      ${rg('k', t, 'sh', 'Shadow', 0, 100)}${rg('k', t, 'op', 'Transparency (100 = solid)', 40, 100)}${rg('k', t, 'rad', 'Corner roundness', 0, 28)}${rg('k', t, 'fs', 'Text size', 11, 18)}${rg('k', t, 'w', 'Panel width', 260, 460)}
      <div class="hint"><b>The little pill</b> (drag it anywhere on the screen)</div>
      <div class="two"><label class="hint">Pill background<input type="color" data-pk="bg" value="${p.bg || t.bg}"></label><label class="hint">Pill text<input type="color" data-pk="fg" value="${p.fg || t.fg}"></label></div>
      <label class="hint">Pill border<input type="color" data-pk="bd" value="${p.bd || '#cccccc'}"></label>
      ${rg('pk', p, 'fs', 'Pill text size', 10, 24)}${rg('pk', p, 'rad', 'Pill roundness', 0, 24)}${rg('pk', p, 'op', 'Pill transparency (100 = solid)', 30, 100)}
      ${cb('pk', p, 'showAuto', 'Show AUTO / MANUAL on the pill')}${cb('pk', p, 'showCounts', 'Show ✓ ✗ counts on the pill')}
      <label class="hint">Preset corner<select data-k="pos">${[['br', 'Bottom right'], ['bl', 'Bottom left'], ['tr', 'Top right'], ['tl', 'Top left']].map(([v, l]) => `<option value="${v}" ${t.pos === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <div class="two"><button class="btn g" id="rp">Use panel colors</button><button class="btn g" id="rpos">Reset position</button></div>
      <div class="hint"><b>Greeting</b></div>
      <label class="hint">Style<select data-ck="greet">${[['namaste', 'Namaste + time of day'], ['hello', 'Hello + time of day'], ['time', 'Time of day only'], ['off', 'Off']].map(([v, l]) => `<option value="${v}" ${cfg.greet === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <label class="hint">Your name (leave empty to read it from CLMS)<input data-ck="userName" value="${esc(cfg.userName)}" placeholder="${esc(cachedName || 'auto')}"></label>
      ${cb('ck', cfg, 'firstName', 'First name only')}${cb('ck', cfg, 'welcome', 'Show a welcome popup when a page opens')}
      <div class="hint"><b>Other</b></div>
      <label class="hint">Undo popup stays for (seconds)<input type="number" id="us" min="1" max="120" value="${cfg.undoSecs}"></label>
      <button class="btn g" id="rs">Reset everything in Style</button></div>`;
    const parse = (el) => (el.type === 'checkbox' ? el.checked : ['range', 'number'].includes(el.type) ? +el.value : el.value);
    const wire = (att, obj) => root.querySelectorAll(`[data-${att}]`).forEach((el) => (el[el.type === 'checkbox' || el.tagName === 'SELECT' ? 'onchange' : 'oninput'] = () => {
      const k = el.dataset[att]; obj()[k] = parse(el);
      const v = root.getElementById('v_' + att + k); if (v) v.textContent = el.value;
      applyTheme(); updatePill(); saveCfg();
    }));
    wire('k', () => cfg.theme); wire('pk', () => cfg.theme.pill); wire('ck', () => cfg);
    root.querySelectorAll('[data-p]').forEach((b) => (b.onclick = () => { [cfg.theme.bg, cfg.theme.fg, cfg.theme.acc] = PRESETS[b.dataset.p]; applyTheme(); saveCfg(); styleTab(); }));
    $('rp').onclick = () => { Object.assign(cfg.theme.pill, { bg: '', fg: '', bd: '' }); applyTheme(); saveCfg(); styleTab(); };
    $('rpos').onclick = () => { cfg.theme.pill.x = cfg.theme.pill.y = null; applyTheme(); saveCfg(); };
    $('us').oninput = (e) => { cfg.undoSecs = Math.max(1, +e.target.value || 5); saveCfg(); };
    $('rs').onclick = () => { const keep = { rules: cfg.rules, visCats: cfg.visCats, visAuto: cfg.visAuto }; cfg = { ...JSON.parse(JSON.stringify(CI_CFG_DEF)), ...keep }; applyTheme(); updatePill(); saveCfg(); styleTab(); };
  }

  chrome.storage.onChanged.addListener(async (ch) => {
    if (ch.ci) { S = await ciLoad(); updatePill(); if (tab === 'tally') tallyTab(); }
    if (ch.ci_cfg) { cfg = await ciCfgLoad(); applyTheme(); updatePill(); }
  });
  updatePill(); applyTheme(); renderBody();
  addEventListener('resize', applyTheme);

  // ---------- open/close: click the pill to open, click anywhere else to close the panel
  let drag = null, justDragged = false;
  $('pl').addEventListener('pointerdown', (e) => { drag = { sx: e.clientX, sy: e.clientY, r: $('pl').getBoundingClientRect(), moved: false }; $('pl').setPointerCapture(e.pointerId); });
  $('pl').addEventListener('pointermove', (e) => {
    if (!drag) return; const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.moved && Math.hypot(dx, dy) < 6) return;
    if (!drag.moved) { drag.moved = true; $('w').classList.remove('open'); drag.r = $('pl').getBoundingClientRect(); drag.sx = e.clientX; drag.sy = e.clientY; return; }
    cfg.theme.pill.x = drag.r.left + (e.clientX - drag.sx); cfg.theme.pill.y = drag.r.top + (e.clientY - drag.sy); applyTheme();
  });
  $('pl').addEventListener('pointerup', () => { if (drag && drag.moved) { justDragged = true; setTimeout(() => (justDragged = false), 0); saveCfg(); } drag = null; });
  $('pl').onclick = () => { if (!justDragged) $('w').classList.toggle('open'); };
  const hidePanel = (e) => { if (!e.composedPath().includes(host)) $('w').classList.remove('open'); };
  document.addEventListener('mousedown', hidePanel, true);
  document.addEventListener('touchstart', hidePanel, true);

  // ---------- undo popup: vanishes by itself after N seconds (default 5)
  let tt;
  function toast(html, undo, secs) {
    const t = $('t');
    t.innerHTML = html + (undo ? '<button id="u">Undo</button>' : '');
    t.style.display = 'block';
    if (undo) $('u').onclick = () => { undo(); lastUndo = null; t.style.display = 'none'; };
    clearTimeout(tt); tt = setTimeout(() => (t.style.display = 'none'), (secs || cfg.undoSecs) * 1000);
  }

  // ---------- who is using it: read the name CLMS shows ("Hello, Sandesh Bhattarai!") and greet them
  (async () => {
    for (let i = 0; i < 20; i++) {
      const mm = document.body.innerText.match(/Hello,?\s+([^\n!]{2,40})!/i);
      if (mm) { cachedName = mm[1].trim(); chrome.storage.local.set({ ci_user: cachedName }); break; }
      await new Promise((r) => setTimeout(r, 1000));
    }
    updatePill();
    const g = ciGreet(cfg, uName());
    if (cfg.welcome && g) toast(g, null, 5);
  })();

  // ---------- which lead + which comment
  function phones(text) {
    const clean = (text || '').replace(/[\s-]/g, '');
    const out = new Set(); let m; const r1 = /(?:977)?(9[78]\d{8})/g;
    while ((m = r1.exec(clean))) out.add(m[1]);
    if (!out.size) { const r2 = /\d{10}/g; while ((m = r2.exec(clean))) out.add(m[0]); }
    return [...out];
  }
  const DLG = '[role=dialog],.modal,[class*=modal],[class*=dialog],[class*=drawer]';
  function leadKey(btn) {
    const dlg = btn.closest(DLG);
    if (dlg) { const p = phones(dlg.innerText); if (p.length) return p[0]; }
    for (const sc of [btn.closest('tr'), btn.closest('[class*=card],[class*=detail],[class*=panel]'), document.body]) {
      if (!sc) continue; const p = phones(sc.innerText); if (p.length === 1) return p[0];
    }
    return null;
  }
  const norm = (x) => x.toLowerCase().replace(/\s+/g, ' ').trim();
  function urlKey() { const m = location.hash.match(/\/([0-9a-f-]{8,}|\d{3,})(?:[/?]|$)/i); return m ? 'u:' + m[1] : null; }
  function fingerprint(btn) {
    const sc = btn.closest(DLG) || btn.closest('tr'); if (!sc) return null;
    const lines = sc.innerText.split('\n').map((x) => x.trim()).filter((x) => x.length > 2 && !/^(save|cancel|close|submit|comment|remark|add|update)/i.test(x));
    return lines.length ? 'f:' + lines.slice(0, 2).join('|').toLowerCase().slice(0, 80) : null;
  }
  function grabComment(btn) {
    const bx = isSendBtn(btn) ? findBox(btn) : null; if (bx && readBox(bx).trim()) return readBox(bx).trim();
    const scope = btn.closest(DLG + ',form') || document;
    const fields = [...scope.querySelectorAll('textarea,input[type=text]')].filter((e) => e.offsetParent && !host.contains(e));
    const pref = fields.filter((e) => /comment|remark|note|feedback/i.test((e.name || '') + (e.placeholder || '') + (e.id || '')));
    const pool = (pref.length ? pref : fields.filter((e) => e.tagName === 'TEXTAREA')).map((e) => e.value.trim()).filter(Boolean);
    return pool.sort((a, b) => b.length - a.length)[0] || '';
  }
  function leadName(btn) {
    const tr = btn.closest('tr');
    if (tr) {
      const tbl = tr.closest('table'), ths = tbl ? [...tbl.querySelectorAll('th')] : [];
      const i = ths.findIndex((h) => /^\s*(student\s*)?name\s*$/i.test(h.innerText));
      const cell = i >= 0 ? tr.children[i] : null;
      if (cell && cell.innerText.trim()) return cell.innerText.trim();
    }
    const dlg = btn.closest(DLG);
    const mm = dlg && dlg.innerText.match(/(?:student\s*)?name\s*[:\-]?\s*\n?\s*([A-Za-z][A-Za-z .'-]{2,40})/i);
    return mm && !/^name$/i.test(mm[1].trim()) ? mm[1].trim() : null;
  }
  function leadPhone(btn, key) {
    if (key && /^\d{10}$/.test(key)) return key;
    const sc = btn.closest(DLG) || btn.closest('tr'); const p = sc ? phones(sc.innerText) : [];
    return p[0] || '';
  }
  const getLast = async () => (await chrome.storage.local.get('ci_last')).ci_last || null;

  // ---------- Send flow: fix spelling + dates first, then let the real Send happen, then count
  const isCountBtn = (b) => /^\s*(save|submit|update|add|send|post|done|confirm)/i.test(b.innerText || b.value || '');
  const isSendBtn = (b) => /^\s*(send|post)\s*$/i.test(b.innerText || '');
  let bypass = false, fixNote = '', lastClick = { t: '', at: 0 };

  async function correct(raw) {
    let out = ciFixText(raw, cfg);
    if (cfg.feat.ai && cfg.aiKey) {
      try { const r = await chrome.runtime.sendMessage({ aiFix: out, key: cfg.aiKey }); if (r && r.text && r.text.length < out.length * 2 + 20) out = r.text; } catch (e) {}
    }
    return out;
  }
  async function beforeSend(b, box) {
    const raw = readBox(box).trim();
    let fixed = raw;
    if (cfg.feat.fix) fixed = await correct(raw);
    if (fixed && fixed !== raw) { writeBox(box, fixed); fixNote = `<br><small>Fixed: “${esc(fixed.slice(0, 90))}”</small>`; } else fixNote = '';
    if (cfg.feat.nfd) { try { await autoNfd(fixed); } catch (e) {} }
    await sleep(150);
    bypass = true; b.click(); bypass = false;
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest('button,[role=button],input[type=submit]');
    if (!b || host.contains(b) || !cfg.feat.on || !isCountBtn(b)) return;
    let box = null, txt = '';
    if (isSendBtn(b)) { box = findBox(b); txt = box ? readBox(box).trim() : ''; }
    if (!txt) txt = grabComment(b);                       // read now, before the page clears the box
    if (!bypass && box && txt.length >= 2 && (cfg.feat.fix || cfg.feat.nfd)) {
      e.preventDefault(); e.stopImmediatePropagation(); beforeSend(b, box); return;
    }
    afterSend(b, txt);
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing || bypass || !cfg.feat.on || !cfg.feat.enter || !(cfg.feat.fix || cfg.feat.nfd)) return;
    const t = e.composedPath()[0];
    if (!t || e.composedPath().includes(host) || !(t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
    const b = findSendBtn(t); if (!b || b.disabled || readBox(t).trim().length < 2) return;
    e.preventDefault(); e.stopImmediatePropagation(); beforeSend(b, t);
  }, true);

  async function afterSend(b, txt) {
    const note = fixNote; fixNote = '';
    const s = await ciLoad();
    if (!s.auto) return note ? toast(note.replace('<br>', '')) : undefined;
    if (txt.length < 2 || (txt === lastClick.t && Date.now() - lastClick.at < 4000)) return;
    lastClick = { t: txt, at: Date.now() };

    let key = leadKey(b) || urlKey() || fingerprint(b);
    const pl = await getLast();
    if (!key && pl && Date.now() - pl.at < 7200000 && norm(txt) !== norm(pl.t) && norm(txt).includes(norm(pl.t))) key = pl.key;
    if (!key) key = 'n:' + Date.now();
    const name = leadName(b), phone = leadPhone(b, key);
    await chrome.storage.local.set({ ci_last: { key, t: txt, at: Date.now(), name, phone } });

    const ids = ciClassify(txt, cfg.rules);
    if (!ids.length) return toast('Ignored by one of your taught rules – nothing counted.' + note);
    const { net, prev } = await ciApplyLead(key, ids);
    let vnote = '';
    if (cfg.visAuto && ids.some((i) => cfg.visCats.includes(i)) && (name || phone)) {
      const ok = await ciAddVisitor({ name: name || 'Lead ' + phone, phone, note: txt.slice(0, 100) });
      if (ok) vnote = '<br><small>+ saved to Interested visitors' + (name ? '' : ' (name not found, used phone)') + '</small>';
    }
    const who = key.startsWith('n:') ? 'could not identify the lead, so it was counted as new' : 'lead ' + key.replace(/^[a-z]:/, '');
    if (!Object.keys(net).length) return toast(`Already counted today – skipped.<br><small>${who}</small>${vnote}${note}`);
    const undo = () => ciRevert(key, net, prev); lastUndo = undo;
    toast(`${prev ? 'Updated' : 'Counted'}: <b>${ids.map(nameOf).join(' + ')}</b><br><small>${who}</small>${vnote}${note}`, undo);
  }

  // M key: mute / unmute all tabs
  ciInstallMuteKey(() => cfg, (msg) => toast(msg, null, 2));
})();
